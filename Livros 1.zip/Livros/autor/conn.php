<?php
    $host ='localhost';
    $dbname = 'bd2504204';
    $username = 'root';
    $password = '';

    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
?>